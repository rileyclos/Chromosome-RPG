const sword_wood_placeholder_meta = [
  "Placeholder Wooden Sword", //Item name
  "This item was used in the early development of this game to aid in development. Fun fact: these words you're seeing right now were typed on the 25th of January, 2023.", //Item description
  "+5", //Health gain
  "-", //Shield gain
  "10", //attack Damage
  "Short" //Range
  //the id is provided by the class name. if for some reason you want to add your own items, edit the items.css file and make a new class for them.
]
const sword_amethyst_meta = [
  "Amethyst Sword",
  "A sword crafted from amethyst and wood. Found by {method}.",
  "-",
  "-",
  "24",
  "Short"
]
const amethyst_meta = [
  "Amethyst",
  "a piece of amethyst bru",
  "-",
  "-",
  "-",
  "-"
]
const coin_meta = [
  "Coin",
  "its a coin. not sure what im gonna do with it",
  "-",
  "-",
  "-",
  "-"
]
const stick_meta = [
  "Stick",
  "The stick is used to make a lot of items, specifically tools and structures.",
  "-",
  "-",
  "-",
  "-"
]
const rock_meta = [
  "Rock",
  "The rock is used to make a lot of Level 2 and 3 items, but is useful in a lot of other cases.",
  "-",
  "-",
  "-",
  "-",
  "-"
]
const player_red_meta = [
  "Red Player",
  "",
  "",
  "",
  "",
  ""
]
const player_orange_meta = [
  "Orange Player",
  "",
  "",
  "",
  "",
  ""
]
const player_yellow_meta = [
  "Yellow Player",
  "",
  "",
  "",
  "",
  ""
]
const player_green_meta = [
  "Green Player",
  "",
  "",
  "",
  "",
  ""
]
const player_blue_light_meta = [
  "Light Blue Player",
  "",
  "",
  "",
  "",
  ""
]
const player_blue_meta = [
  "Blue Player",
  "",
  "",
  "",
  "",
  ""
]
const player_purple_meta = [
  "Purple Player",
  "",
  "",
  "",
  "",
  ""
]
const player_pink_meta = [
  "Pink Player",
  "",
  "",
  "",
  "",
  ""
]
